package com.exam;

public class User {
    public String name;
    public int money;
    public User(String name,int money){
        this.name = name;
        this.money = money;
    }
}
