package com.exam;

import java.io.PrintStream;
import java.util.Scanner;
import java.util.ArrayList;

public class Index {
    int d = 10;
    int e = 10;
    int add(int a,int b){
        return a+b;
    }
    void __exec(PrintStream out){
        out.print(add(10,20));
    }
}
