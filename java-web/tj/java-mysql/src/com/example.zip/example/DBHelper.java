package com.example;

import java.io.Closeable;
import java.io.IOException;
import java.sql.*;

public class DBHelper implements Closeable {
    static  {
        try {
            Class.forName("com.mysql.jdbc.Driver"); // 加载驱动
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    final Connection con;
    public DBHelper() throws SQLException {
        // 构造函数创建一个java-mysql连接
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb","root","root");
    }
    public int Update(String sql) throws Exception{
        // update，delete，insert
        Statement st = con.createStatement();
        int c = st.executeUpdate(sql);
        st.close();
        return c;
    }

    public Object Query(String sql,SqlExectuer exc) throws SQLException{
        Statement st = con.createStatement();
        ResultSet rs = st.executeQuery(sql);
        Object o = exc.exec(rs);
        rs.close();
        return o;
    }

    @Override
    public void close() throws IOException {
        try {
            con.close();
        } catch (SQLException throwable) {
            throw new IOException(throwable);
        }
    }
}
