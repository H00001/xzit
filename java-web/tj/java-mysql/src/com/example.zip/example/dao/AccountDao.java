package com.example.dao;

import com.example.DBHelper;
import com.example.SqlExectuer;
import com.example.data.Account;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class AccountDao {
    private final DBHelper helper;
    public AccountDao() throws SQLException{
        helper = new DBHelper();
    }
    public Account queryById(int id) throws SQLException {
        Object res = helper.Query("select * from account where id="+id,rs -> {
            if (!rs.next()) {
                return null;
            }
            int _id = rs.getInt("id");
            String name = rs.getString("name");
            int math = rs.getInt("math");
            int english = rs.getInt("english");
            int clazz = rs.getInt("class");
            return new Account(_id, name, math, english, clazz);
        });
        return (Account)res;
    }

    public List<Account> QueryAll() throws SQLException {
        List<Account> acc = new ArrayList<>();
        helper.Query("select * from account", rs -> {
            while (rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("name");
                int math = rs.getInt("math");
                int english = rs.getInt("english");
                int clazz = rs.getInt("class");
                Account a = new Account(id, name, math, english, clazz);
                acc.add(a);
        }
            return acc;
    });
    return acc;
    }
}